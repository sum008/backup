package com.fourth;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AddToDatabase extends HttpServlet {
	
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException {
		res.setContentType("text/html"); 
		PrintWriter out=res.getWriter();
		Connection con = MyConnection.getConnection();
		
		//ADD TO DATABASE
		if(req.getParameter("add")!=null) {
	
		
		if(req.getParameter("id").length()!=0 && req.getParameter("age").length()!=0 && req.getParameter("roll").length()!=0 && req.getParameter("name").length()!=0) {
			
			int id = Integer.parseInt(req.getParameter("id"));
			int age =Integer.parseInt(req.getParameter("age"));
			int rollno=Integer.parseInt(req.getParameter("roll"));
			String x=req.getParameter("name");
			
			String query1 = "select id FROM students WHERE id="+id;
			try {
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(query1);
				if(rs.first()==false) {
					
					String name="'";
					for(int i =0; i<x.length(); i++) {
						
						name=name+x.charAt(i);
					}
					
					name=name+"'";
					String sqlQuey="insert into students values("+id+","+ name+","+age+","+rollno+")";
					
					try {	
						Statement stmt1 = con.createStatement();
						stmt1.executeUpdate(sqlQuey);
						out.println("Added Successfully !!");
						RequestDispatcher rd = req.getRequestDispatcher("/form.html");
						rd.include(req, res);
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}else {
					out.println("Data with id "+id+" is already present in database !!");
					RequestDispatcher rd = req.getRequestDispatcher("/form.html");
					rd.include(req, res);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}else {
			
			//ALL FIELDS ARE NECESSARY TO BE FILLED FOR ADDING TO DATABASE
			out.println("All fields are necessary to add to database !!");
			RequestDispatcher rd = req.getRequestDispatcher("/form.html");
			rd.include(req, res);
		}
		
	}
		//VIEW DATABASE ITEMS 
		else if(req.getParameter("view")!=null) {
			
			String sqlQuey="SELECT * FROM students ORDER BY id";
			try {	
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sqlQuey);
				boolean b=rs.first();
				if(rs.first()==true) {
				out.println("<html>");
				out.println("<head>");
				out.println("</head>");
				out.println("<body>");
				
				out.println(
						"<table style='border:1px solid black; border-collapse: collapse;'>\n" + 
						"  <tr style='border:1px solid black;'>\n" + 
						"    <th style='border:1px solid black;'>Id</th>\n" + 
						"    <th style='border:1px solid black;'>Name</th>\n" + 
						"    <th style='border:1px solid black;'>Age</th>\n" + 
						"    <th style='border:1px solid black;'>RollNo.</th>\n" + 
						"  </tr>\n");
				
				while(b) {
					
					int id = rs.getInt("id");
					String name=rs.getString("name");
					int age=rs.getInt("age");
					int rollno=rs.getInt("rollno");
					out.println( 
							"  <tr style='border:1px solid black;'>\n" + 
								"    <th style='border:1px solid black;'>"+id+"</th>\n" + 	
								"    <th style='border:1px solid black;'>"+name+"</th>\n" +
								"    <th style='border:1px solid black;'>"+age+"</th>\n" +
								"    <th style='border:1px solid black;'>"+rollno+"</th>\n" +
								"  </tr>\n");
					b=rs.next();
						}
					out.println("</table>");
					out.println("<button onclick=window.location.href='form.html' >Home</button>\n");
					out.println("</body>");
					out.println("</html>");
					
					
				}else {
					out.println("<html>");
					out.println("<head>");
					out.println("</head>");
					out.println("<body>");
					out.println("<h2>No data available!</h2>");
					out.println("<button onclick=window.location.href='form.html' >Home</button>\n");
					out.println("</body>");
					out.println("</html>");
					stmt.close();
				}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			
		//DELETE ITEM FROM DATABASE BASED UPON ID
		}else if(req.getParameter("delete")!=null) {
			
			RequestDispatcher rd = req.getRequestDispatcher("/delete.html");
			rd.include(req, res);
			
		//UPDATE DATABASE
		}else if(req.getParameter("update")!=null) {
			
			String sqlQuey1="select * FROM students";
			
			try {
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sqlQuey1);
				if(rs.first()==false) {
					out.println("Database is empty. Can't update");
					RequestDispatcher rd = req.getRequestDispatcher("/form.html");
					rd.include(req, res);
				}else {
					RequestDispatcher rd = req.getRequestDispatcher("/update.html");
					rd.include(req, res);
				}
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
