package com.fourth;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RemoveFromDatabase extends HttpServlet {
	
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException {
		res.setContentType("text/html"); 
		PrintWriter out=res.getWriter();
		Connection con = MyConnection.getConnection();
		
		if(req.getParameter("home")!=null) {
			
			RequestDispatcher rd = req.getRequestDispatcher("/form.html");
			rd.include(req, res);
		}
		else {
		//DELETE BUTTON IS PRESSED
		if(req.getParameter("deleteid").length()!=0) {
			
			int id1=Integer.parseInt(req.getParameter("deleteid"));
			String query1 = "select id FROM students WHERE id="+id1;
			try {
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(query1);
				
				//NO DATA EXISTS IN DATABASE
				if(rs.first()==false) {
					
					out.println("No such id exists. Please enter valid id");
					RequestDispatcher rd = req.getRequestDispatcher("/delete.html");
					rd.include(req, res);
					
				//DATA EXISTS IN DATABASE	
				}else {
					
					String sqlQuey1="DELETE FROM students WHERE id = "+id1;
					try {
						
						String sqlQuey="select * FROM students WHERE id="+id1;
						ResultSet rs2 = stmt.executeQuery(sqlQuey);
						rs2.next();
						int id=rs2.getInt("id");
						String name=rs2.getString("name");
						int age = rs2.getInt("age");
						int roll = rs2.getInt("rollno");
						
						stmt.executeUpdate(sqlQuey1);
						String sqlQuey3="select * FROM students";
						try {
							ResultSet rs1 = stmt.executeQuery(sqlQuey3);
							if(rs1.first()==true) {
								
								//VIEW THE DELETED DATA ON PAGE
								out.println("Data with id : "+id+", name : "+name+", age : "+age+" and rollno : "+roll+" has been removed successfully.");
								RequestDispatcher rd = req.getRequestDispatcher("/delete.html");
								rd.include(req, res);
								
							//LAST PRESENT DATA IS REMOVED FROM DATABASE. REDIRECT TO HOMEPAGE
							}else {
								RequestDispatcher rd = req.getRequestDispatcher("/form.html");
								rd.include(req, res);
							}
						} catch (SQLException e) {
							e.printStackTrace();
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} 
			
			
		}
		
	}
	}
}
