package com.fourth;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateDatabase extends HttpServlet{
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		//select id FROM students WHERE id=1
		res.setContentType("text/html"); 
		PrintWriter out=res.getWriter();
		Connection con = MyConnection.getConnection();
		
		if(req.getParameter("home")!=null) {
			RequestDispatcher rd = req.getRequestDispatcher("/form.html");
			rd.include(req, res);
			
		}else {
		
			if(req.getParameter("id").length()!=0) {
				int id=Integer.parseInt(req.getParameter("id"));
				String query1 = "select id FROM students WHERE id="+id;
				try {
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery(query1);
					if(rs.first()==false) {
						out.println("No such id exists. Please enter valid id");
						RequestDispatcher rd = req.getRequestDispatcher("/update.html");
						rd.include(req, res);
					}else {
						if(req.getParameter("name").length()!=0 || req.getParameter("age").length()!=0 || req.getParameter("roll").length()!=0) {
							
							//UPDATE NAME
							if(req.getParameter("name").length()!=0) {
								String x = req.getParameter("name");
								String name="'";
								
								for(int i =0; i<x.length(); i++) {
									
									name=name+x.charAt(i);
								}
								
								name=name+"'";
								String query="UPDATE students SET name ="+ name+" WHERE id = "+id;
								try {
									Statement stmt0 = con.createStatement();
									stmt0.executeUpdate(query);
								} catch (SQLException e) {
									e.printStackTrace();
								}
							}
							//UPDATE AGE
							if(req.getParameter("age").length()!=0) {
								int age = Integer.parseInt(req.getParameter("age"));
								
								String query="UPDATE students SET age ="+ age+" WHERE id = "+id;
								try {
									Statement stmt1 = con.createStatement();
									stmt1.executeUpdate(query);
								} catch (SQLException e) {
									e.printStackTrace();
								}
							}
							//UPDATE ROLLNO
							if(req.getParameter("roll").length()!=0) {
								int roll = Integer.parseInt(req.getParameter("roll"));
								
								String query="UPDATE students SET rollno ="+ roll+" WHERE id = "+id;
								try {
									Statement stmt2 = con.createStatement();
									stmt2.executeUpdate(query);
								} catch (SQLException e) {
									e.printStackTrace();
								}
							}
							out.print("Updated Successfull !!");
							RequestDispatcher rd = req.getRequestDispatcher("/update.html");
							rd.include(req, res);
							
							
						}else {
							out.print("Nothing Updated !!");
						}
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}else {
				
				out.print("Please enter id !!");
				RequestDispatcher rd = req.getRequestDispatcher("/update.html");
				rd.include(req, res);
			}
	}
	}

}
