package com.fourth;

import java.sql.Connection;
import java.sql.DriverManager;

public class MyConnection {
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
    static final String DB_URL="jdbc:mysql://localhost:3306/mydatabase?useSSL=false";
    static final String USER = "root";
    static final String PASSWORD = "root";
    static Connection connection=null;
    public static Connection getConnection(){
    try {
    	Class.forName(JDBC_DRIVER);
    	connection=DriverManager.getConnection(DB_URL, USER, PASSWORD);
    }catch(Exception e) {
    	System.out.println(e.getMessage()+"545454545");
    }
    return connection;
    }
    
}
