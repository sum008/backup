package com.log;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class PasswordUpdate
 */
public class PasswordUpdate extends HttpServlet {
	
	public String makeString(String s) {
		String name="'";
		for(int i =0; i<s.length(); i++) {
			
			name=name+s.charAt(i);
		}
		
		name=name+"'";
		return name;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html"); 
		PrintWriter out=response.getWriter();
		
		HttpSession session=request.getSession();
		if(session.getAttribute("data")==null){
			response.sendRedirect("login.html");
		}else {
			
			MyConnections2 con = new MyConnections2();
			Connection c = con.getConnection("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost:3306/users?useSSL=false", "root", "root");
			
			if(request.getParameter("new").length()>0 && request.getParameter("confirm").length()>0) {
				
				String newPass=makeString(request.getParameter("new"));
				String confirmPass=makeString(request.getParameter("confirm"));
				
				if(newPass.equals(confirmPass)) {
					String[] a=(String[])session.getAttribute("data");
					String uname=a[0];
					String mobile=a[1];
					String query="UPDATE Persons SET password="+newPass+" WHERE BINARY mobile="+mobile+" AND BINARY username="+uname;
					Statement stmt;
					try {
						stmt = c.createStatement();
						stmt.executeUpdate(query);
						session.removeAttribute("data");
						response.sendRedirect("login.html");
						out.println("<script type=\"text/javascript\">");
					    out.println("alert('Password changed successfully!!');");
					    out.println("</script>");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
				}else {
					
					out.println("<p align ='center' style='color:rgb(187, 189, 191);'>Password did't match!!</p>");
					RequestDispatcher rd = request.getRequestDispatcher("/changePassword.html");
					rd.include(request, response);
					
				}
				
				
			}else {
				
				out.println("<p align ='center' style='color:rgb(187, 189, 191);'>All fields are necessary!!</p>");
				RequestDispatcher rd = request.getRequestDispatcher("/changePassword.html");
				rd.include(request, response);
			}
			
		}
		
		
	}
}
