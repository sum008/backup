package com.log;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginCurrentUser extends HttpServlet{
	
	public String makeString(String s) {
		String name="'";
		for(int i =0; i<s.length(); i++) {
			
			name=name+s.charAt(i);
		}
		
		name=name+"'";
		return name;
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html"); 
		PrintWriter out=res.getWriter();
		if(req.getParameter("login")!=null) {
			
			MyConnections2 con = new MyConnections2();
			Connection c = con.getConnection("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost:3306/users?useSSL=false", "root", "root");
			
			String username=makeString(req.getParameter("uname"));
			String password=makeString(req.getParameter("pass"));
			
			String query="select * FROM Persons WHERE username="+username+" AND password="+password;
			Statement stmt;
			try {
				stmt = c.createStatement();
				ResultSet s1 =stmt.executeQuery(query);
				
				int count=0;
				while(s1.next()) {
					count+=1;
				}
				//IF USERNAME AND PASSWORD IS PRESENT MORE THAN ONCE IN DATABASE REDIRECT TO MOBILE VERIFICATION PAGE
				if(count>1) {
					HttpSession session=req.getSession();
					query="select * FROM Persons WHERE username="+username+" AND password="+password;
					Statement stmt1 = c.createStatement();
					ResultSet s2 =stmt1.executeQuery(query);
					s2.next();
					String mobile=makeString(s2.getString("mobile"));
					String[] data = new String[3];
					data[0]=username;
					data[1]=password;
					data[2]=mobile;
					
					session.setAttribute("data", data);
					res.sendRedirect("mobileValidate.jsp");
					
				//ELSE REDIRECT TO USER PAGE
				}else if(count==1) {
					HttpSession session=req.getSession();
					query="select * FROM Persons WHERE username="+username+" AND password="+password;
					Statement stmt1 = c.createStatement();
					ResultSet s2 =stmt1.executeQuery(query);
					s2.next();
					String mobile=makeString(s2.getString("mobile"));
					String[] data = new String[3];
					data[0]=username;
					data[1]=password;
					data[2]=mobile;
					session.setAttribute("data", data);
					res.sendRedirect("User.jsp");
				}else {
					out.println("invalid usernam or password!! "+s1.getFetchSize());
					RequestDispatcher rd = req.getRequestDispatcher("login.html");
					rd.include(req, res);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}else if(req.getParameter("new")!=null) {
			
			RequestDispatcher rd = req.getRequestDispatcher("/newUser.html");
			rd.include(req, res);
		}
	}

}
