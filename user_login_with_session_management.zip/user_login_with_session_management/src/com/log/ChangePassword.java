package com.log;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class ChangePassword extends HttpServlet {
	
	public String makeString(String s) {
		String name="'";
		for(int i =0; i<s.length(); i++) {
			
			name=name+s.charAt(i);
		}
		
		name=name+"'";
		return name;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//get old password from request
		//get new password from request
		//get username from session
		//extract password from that username using sql query
		//first compare extracted password and old password
		//if those two matches then change the password 
		//else redirect to change password page
		HttpSession session=request.getSession();
		if(session.getAttribute("data")==null){
			response.sendRedirect("login.html");
		}else {
			
			response.setContentType("text/html"); 
			PrintWriter out=response.getWriter();
			
			MyConnections2 con = new MyConnections2();
			Connection c = con.getConnection("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost:3306/users?useSSL=false", "root", "root");
			
			if( request.getParameter("old").length()>0 && request.getParameter("new").length()>0 && request.getParameter("confirm").length()>0) {
			
				String oldpass=makeString(request.getParameter("old"));
				String newPass=makeString(request.getParameter("new"));
				String confirmPass=makeString(request.getParameter("confirm"));
				
				String[] a=(String[])session.getAttribute("data");
				String pass=a[1];
				String mobile=a[2];
				
				if(oldpass.equals(pass)) {
				
				if(newPass.equals(confirmPass)) {
					String query="UPDATE Persons SET password="+newPass+" WHERE mobile="+mobile;
					try {
						Statement stmt = c.createStatement();
						stmt.executeUpdate(query);
						
						String[] data = new String[3];
						data[0]=a[0];
						data[1]=newPass;
						data[2]=mobile;
						
						session.setAttribute("data", data);
						out.println("<script type=\"text/javascript\">");
					    out.println("alert('Password successfully changed!!');");
					    out.println("</script>");
					    RequestDispatcher rd = request.getRequestDispatcher("User.jsp");
						rd.include(request, response);
						
						
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else {
					
					out.println("<p align ='center' style='color:rgb(187, 189, 191);'>Password invalid!!</p>");
					RequestDispatcher rd = request.getRequestDispatcher("/changePassword.jsp");
					rd.include(request, response);
				}
			}else {
				
				out.println("<p align ='center' style='color:rgb(187, 189, 191);'>Invalid old password!!</p>");
				RequestDispatcher rd = request.getRequestDispatcher("/changePassword.jsp");
				rd.include(request, response);
			}
		}else {
			
			out.println("<p align ='center' style='color:rgb(187, 189, 191);'>All fields are necessary!!</p>");
			RequestDispatcher rd = request.getRequestDispatcher("/changePassword.jsp");
			rd.include(request, response);
		}
		}
		
		
		

}
}