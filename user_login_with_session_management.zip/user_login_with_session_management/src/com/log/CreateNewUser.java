package com.log;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class CreateNewUser extends HttpServlet{
	
	public String makeString(String s) {
		String name="'";
		for(int i =0; i<s.length(); i++) {
			
			name=name+s.charAt(i);
		}
		
		name=name+"'";
		return name;
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		res.setContentType("text/html"); 
		PrintWriter out=res.getWriter();
		
		if(req.getParameter("mobile").length()>0 && req.getParameter("uname").length()>0 && req.getParameter("mobile").length()>0) {
		
				if(req.getParameter("mobile").length()==10) {
					
					boolean cont=true;
					String mobile=makeString(req.getParameter("mobile")).substring(1, 11);
					System.out.println(mobile.length());
					/* 
					 * String mob=mobile.toLowerCase();
					 * String check="abcdefghijklmnopqrstuvwxyz`~!@#$%^&*()_-+=[{]}|';:/?.>,<$%' ''\'";
					 * for(int i=0; i<check.length(); i++) {
					 * 
					 * if(mob.contains(String.valueOf(check.charAt(i)))) {
					 * System.out.println(mob+"  "+mob.length()); cont=false; break; } }
					 */
					
					for(int i=0; i<10;i++) {
						if(!String.valueOf(mobile.charAt(i)).matches("[0-9]")) {
							cont=false;
							break;
						}
					}
				System.out.println(cont);
			if(cont==true){
				
				
				String query="select * FROM Persons WHERE mobile="+mobile;
				MyConnections2 con = new MyConnections2();
				Connection c = con.getConnection("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost:3306/users?useSSL=false", "root", "root");
				
				try {
					Statement stmt = c.createStatement();
					ResultSet s =stmt.executeQuery(query);
					if(s.first()==true) {
						out.println("<p align ='center' style='color:rgb(187, 189, 191);'>Mobile number already exists!!</p>");
						RequestDispatcher rd = req.getRequestDispatcher("/newUser.html");
						rd.include(req, res);
					}else {
						
						String username=makeString(req.getParameter("uname"));
						String password=makeString(req.getParameter("pass"));
						query="insert into Persons values("+username+","+password+","+mobile+")";
						stmt.executeUpdate(query);
						out.println("<script type=\"text/javascript\">");
						out.println("alert('Account successfully created!!');");
						out.println("</script>");
						
						RequestDispatcher rd = req.getRequestDispatcher("/login.html");
						rd.include(req, res);
						
					}	
	
				} catch (SQLException e) {
					e.printStackTrace();
				}	
				
			}else {
				cont=true;
				out.println("<p align ='center' style='color:rgb(187, 189, 191);'>Invalid mobile number!!</p>");
				RequestDispatcher rd = req.getRequestDispatcher("/newUser.html");
				rd.include(req, res);
			}
				
		}else {
				
				out.println("<p align ='center' style='color:rgb(187, 189, 191);'>Invalid mobile number!!</p>");
				RequestDispatcher rd = req.getRequestDispatcher("/newUser.html");
				rd.include(req, res);
		}
				
		}else {
			out.println("<p align ='center' style='color:rgb(187, 189, 191);'>All fields are mandatory!</p>");
			RequestDispatcher rd = req.getRequestDispatcher("/newUser.html");
			rd.include(req, res);
		}
  }

}
