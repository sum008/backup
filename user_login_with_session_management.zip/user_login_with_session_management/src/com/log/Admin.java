package com.log;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AdminShow
 */
public class Admin extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		
		if(session.getAttribute("data")==null) {
			response.sendRedirect("login.html");
		}else {
		
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter();
		if(request.getParameter("show")!=null) {
			
			MyConnections2 con = new MyConnections2();
			Connection c = con.getConnection("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost:3306/users?useSSL=false", "root", "root");
			String query = "Select * FROM Persons";
			
			Statement stmt;
			try {
				stmt = c.createStatement();
				ResultSet rs = stmt.executeQuery(query);
				boolean b=rs.first();
					/* ArrayList<String[]> list = new ArrayList<String[]>(); */
				if(rs.first()==true) {
				out.println("<html>");
				out.println("<head>");
				out.println("<link rel='stylesheet' href='bootstrap.min.css\'>");
				out.println("</head>");
				out.println("<body>");
				
				out.println(
						"<table style='border:0 solid black; border-collapse: collapse; ' align='center'>\n" + 
						"  <tr style='border:1px solid black;'>\n" + 
						"    <th style='border:1px solid black; padding: 20px;'>Username</th>\n" + 
						"    <th style='border:1px solid black; padding: 20px;'>Password</th>\n" + 
						"    <th style='border:1px solid black; padding: 20px;'>Mobile</th>\n" + 
						"  </tr>\n");
				
				while(b) {
					
					String uname = rs.getString("username");
					String pass=rs.getString("password");
					String mobile=rs.getString("mobile");
							/*
							 * String[] arr = new String[3];
							 * arr[0]=uname;arr[1]=pass;arr[2]=mobile;list.add(arr);
							 */
					
					out.println( 
							"  <tr style='border:1px solid black; padding: 50px;'>\n" + 
								"    <th style='border:1px solid black; padding: 10px;'>"+uname+"</th>\n" + 	
								"    <th style='border:1px solid black; padding: 10px;'>"+pass+"</th>\n" +
								"    <th style='border:1px solid black; padding: 10px;'>"+mobile+"</th>\n" +
								"  </tr>\n");
					b=rs.next();
						}
						/*
						 * HttpSession sess = request.getSession(); sess.setAttribute("list", list);
						 * response.sendRedirect("show.jsp");
						 */
					out.println("<tr>");
					out.println("<td colspan='4' align='right' style='padding-top:20px;'> <input type='submit' value='Home'  onclick=window.location.href='admin.jsp' class='btn btn-primary btn-lg btn-dark'> </td>\n");
					out.println("</tr>");
					out.println("</table>");
					out.println("</body>");
					out.println("</html>");
					
					
				}else {
					out.println("<html>");
					out.println("<head>");
					out.println("</head>");
					out.println("<body>");
					out.println("<h2>No data available!</h2>");
					out.println("<input type='submit' value='Home' onclick=window.location.href='admin.jsp' class='btn btn-primary btn-lg btn-dark'>\n");
					out.println("</body>");
					out.println("</html>");
					stmt.close();
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(request.getParameter("remove")!=null) {
			
			response.sendRedirect("removeUser.jsp");
		}
	}
	
	}

}
