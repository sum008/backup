package com.log;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Forgot
 */
public class Forgot extends HttpServlet {
	
	public String makeString(String s) {
		String name="'";
		for(int i =0; i<s.length(); i++) {
			
			name=name+s.charAt(i);
		}
		
		name=name+"'";
		return name;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html"); 
		PrintWriter out=response.getWriter();
		
			MyConnections2 con = new MyConnections2();
			Connection c = con.getConnection("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost:3306/users?useSSL=false", "root", "root");
			
			String username=makeString(request.getParameter("uname"));
			String mobile=makeString(request.getParameter("mobile"));
			
			String query="select * FROM Persons WHERE BINARY username="+username+" AND mobile="+mobile;
			
			try {
				Statement stmt = c.createStatement();
				ResultSet rs = stmt.executeQuery(query);
				int count=0;
				while(rs.next()) {
					count+=1;
				}
				
				if(count<=0) {
					out.println("<p align ='center' style='color:rgb(187, 189, 191);'>Invalid username or mobile!!</p>");
					RequestDispatcher rd = request.getRequestDispatcher("/forgot.html");
					rd.include(request, response);
				}else if(count==1) {
					HttpSession session=request.getSession();
					String[] data = new String[2];
					data[0]=username;
					data[1]=mobile;
					
					session.setAttribute("data", data);
					response.sendRedirect("setNewPassword.jsp");
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}

}
