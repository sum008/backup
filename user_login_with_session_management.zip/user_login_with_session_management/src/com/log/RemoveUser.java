package com.log;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class RemoveUser
 */
public class RemoveUser extends HttpServlet {
	
	public String makeString(String s) {
		String name="'";
		for(int i =0; i<s.length(); i++) {
			
			name=name+s.charAt(i);
		}
		
		name=name+"'";
		return name;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		
		if(session.getAttribute("data")==null) {
			response.sendRedirect("login.html");
		}else {
		
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter();
		
		MyConnections2 con = new MyConnections2();
		Connection c = con.getConnection("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost:3306/users?useSSL=false", "root", "root");
		
		String mobile=makeString(request.getParameter("mobile"));
		String query = "select * FROM Persons WHERE mobile="+mobile;
		
		Statement stmt;
		try {
			stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			//NO DATA EXISTS IN DATABASE
			if(rs.first()==false) {
				
				out.println("<p align ='center' style='color:rgb(187, 189, 191);'>Invalid mobile number!!</p>");
				RequestDispatcher rd = request.getRequestDispatcher("removeUser.jsp");
				rd.include(request, response);
				
			//DATA EXISTS IN DATABASE	
			}else {
				
				 query="DELETE FROM Persons WHERE mobile = "+mobile;
				try {
					
					String sqlQuey="select * FROM Persons WHERE mobile = "+mobile;
					ResultSet rs2 = stmt.executeQuery(sqlQuey);
					rs2.next();
					String uname = rs2.getString("username");
					String pass=rs2.getString("password");
					
					stmt.executeUpdate(query);
					String sqlQuey3="select * FROM Persons";
					try {
						ResultSet rs1 = stmt.executeQuery(sqlQuey3);
						if(rs1.first()==true) {
							
							//VIEW THE DELETED DATA ON PAGE
							out.println("<p align ='center' style='color:rgb(187, 189, 191);'>Data with username :"+uname+" password :" +pass+" , mobile :"+mobile + "has been removed successfully.</p>");
							
							RequestDispatcher rd = request.getRequestDispatcher("removeUser.jsp");
							rd.include(request, response);
							
						//LAST PRESENT DATA IS REMOVED FROM DATABASE. REDIRECT TO HOMEPAGE
						}else {
							RequestDispatcher rd = request.getRequestDispatcher("admin.jsp");
							rd.include(request, response);
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	}
	

}
