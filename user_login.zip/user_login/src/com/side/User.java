package com.side;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class User extends HttpServlet{
	
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException {
		res.setContentType("text/html"); 
		PrintWriter out=res.getWriter();
		
		String[] a=(String[]) req.getAttribute("Userdata");
		System.out.print(a);
		String uname=a[0].substring(1, a[0].length()-1);
		String pass=a[1];
		String mobile=a[2];
		
		out.println("<html>");
		out.println("<head>");
		out.println("</head>");
		out.println("<body>");
		out.println("<h2>Welcome "+uname+", </h2>");
		out.println("<button onclick=window.location.href='login.html' >Logout</button>\n");
		out.println("</body>");
		out.println("</html>");
	}

}
